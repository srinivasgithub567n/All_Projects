package com.evry.employees.employeesdemo;

import org.junit.Test;
import org.junit.runner.RunWith;



public class EmployeesDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
