package com.evry.employees.employeesdemo.util;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class HibernateUtil {
	
@Autowired
private SessionFactory sessionFactory;
	
	public Session getSession()
{
	
	System.out.println(new HibernateUtil().sessionFactory);
	Session session=null;
if(session==null)
	{
		
		session=sessionFactory.openSession();
}

	return session;
}
	
	/*@Autowired
    private EntityManager entityManager;

    public Session getSession() {
        return entityManager.unwrap(Session.class);
    }*/
	
	

}
