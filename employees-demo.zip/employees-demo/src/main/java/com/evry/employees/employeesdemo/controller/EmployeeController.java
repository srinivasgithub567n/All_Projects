package com.evry.employees.employeesdemo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.evry.employees.employeesdemo.model.Employee;
import com.evry.employees.employeesdemo.model.EmployeeIds;
import com.evry.employees.employeesdemo.service.EmployeeService;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeController {
	
	@Autowired
	EmployeeService  employeeService;

	@PostMapping("/addEmployee")
	 public Employee addEmployee(@RequestBody Employee employee)
	 {
		 System.out.println("This is addEmployee method which accespts the get request");
		System.out.println(employee.getEmployeeBasicDetails().getFullName()+" "+employee.getEmployeeBasicDetails().getEmail()+" "+employee.getEmployeeMoreDetails().getHireDate()+" "+employee.getEmployeeMoreDetails().isMaritalStatus());
	
		employee=employeeService.addEmployee(employee);
		
		
		
		 return employee;
	 }
	
	@GetMapping("/getEmployeeList")
	public List<Employee> getEmployeeList()
	{
		System.out.println("control reached to controller");
		return employeeService.getEmployeeList();
	}
	
	@DeleteMapping("/deleteEmployee/{id}")
	public boolean deleteEmployee(@PathVariable int id)
	{
		System.out.println(id);
		
		return employeeService.deleteEmployee(id);
	}
	
	@PutMapping("/editEmployee")
    public boolean editEmployee(@RequestBody Employee employee)
    {
	
		System.out.println(employee.getId()+" "+employee.getEmployeeBasicDetails().getFullName()+" "+employee.getEmployeeBasicDetails().getEmail()+" "+employee.getEmployeeMoreDetails().getHireDate()+" "+employee.getEmployeeMoreDetails().isMaritalStatus());
		return employeeService.editEmployee(employee);
	}
	
	@PostMapping("/deleteEmployees")
	public boolean deleteEmployees(@RequestBody EmployeeIds employeeIds)
	{
		System.out.println(employeeIds.getEmployeeIds().length);
		return employeeService.deleteEmployees(employeeIds);
	}
	
}
