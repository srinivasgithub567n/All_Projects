package com.evry.employees.employeesdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evry.employees.employeesdemo.dao.EmployeeDao;
import com.evry.employees.employeesdemo.model.Employee;
import com.evry.employees.employeesdemo.model.EmployeeIds;


@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDao employeeDao;
	
	
	public Employee addEmployee(Employee employee)
	{  
		
		employee=employeeDao.addEmployee(employee);
		
		return employee;
	}
	
	public List<Employee> getEmployeeList()
	{
		
		return employeeDao.getEmployeeList();
	}
	
	public boolean deleteEmployee(int id)
	{
	   return employeeDao.deleteEmployee(id);	
	}
	
	public boolean editEmployee(Employee employee)
	{
		return employeeDao.editEmployee(employee);
	}

	@Override
	public boolean deleteEmployees(EmployeeIds employeeIds) {
		
		return employeeDao.deleteEmployees(employeeIds);
	}

}
