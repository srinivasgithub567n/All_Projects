package com.evry.employees.employeesdemo.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evry.employees.employeesdemo.customexceptions.EmployeeNotFound;
import com.evry.employees.employeesdemo.model.Employee;
import com.evry.employees.employeesdemo.model.EmployeeIds;



@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	

@Autowired
private SessionFactory sessionFactory;
private Employee employee1;
private boolean flag=true;
	
	public Employee addEmployee(Employee employee)
	{  
		 Transaction transaction=null;
		 Session session=null;
		 Serializable id=null;
		try {

			//session=sessionFactory.openSession();
			//session=new HibernateUtil().getSession();
			session = getSession();
			transaction=session.beginTransaction();
			id=session.save(employee);
			
			System.out.println(id);
			

			transaction.commit();
			Integer primaryId=(Integer)id;
			int pid=primaryId.intValue();
			employee.setId(pid);

		} catch (Exception e) {

			transaction.rollback();

			e.printStackTrace();
		}
		

		return employee;
		
		
	}
	
	public List<Employee> getEmployeeList()
	{
		//System.out.println(sessionFactory);
		Session session=null;
		//Transaction transaction=null;
		List<Employee> employeeList=null;
		System.out.println("control reached to Dao method");
		try { 

			//session=new HibernateUtil().getSession();
			session = getSession();
			//session=new HibernateUtil().getSession();
			String sql = ("from Employee");
			Query query=session.createQuery(sql);
			employeeList = query.list();

			

		} catch (Exception e) {

	
			e.printStackTrace();
		}

		return employeeList;
		
	}
	
	
	public boolean deleteEmployee(int id)
	{
		Session session=null;
		Transaction transaction=null;
		
		
		
		try {

			//session=sessionFactory.openSession();
			//session=new HibernateUtil().getSession();
			//session=new HibernateUtil().getSession();
			session = getSession();
			transaction=session.beginTransaction();
			
			employee1=session.get(Employee.class,id);
			if(employee1!=null)
			session.delete(employee1);
			else
//				throw new EmployeeNotFound("No Employee Found with proivded employee id");
				flag=false;
			

			transaction.commit();

		} catch (Exception e) {
            flag=false;
			transaction.rollback();
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean editEmployee(Employee employee)
	{
		
		Session session=null;
		Transaction transaction=null;
		try {

			//session=sessionFactory.openSession();
			//session=new HibernateUtil().getSession();
			session = getSession();
			//session=new HibernateUtil().getSession();
			transaction=session.beginTransaction();
//	employee=session.get(Employee.class,employee.getId());
			
			if(employee!=null)
			session.update(employee);
	else
			flag=false;
		

			transaction.commit();

		} catch (Exception e) {
             flag=false;
			transaction.rollback();
			e.printStackTrace();
		}
		return flag;
	}
	
	private Session getSession()
	{
		
		//System.out.println(new HibernateUtil().sessionFactory);
		Session session=null;
	if(session==null)
		{
			
			session=sessionFactory.openSession();
	}

		return session;
	}

	@Override
	public boolean deleteEmployees(EmployeeIds employeeIds) {
		
		Session session=null;
		Transaction transaction=null;
		int[] ids=employeeIds.getEmployeeIds();
		try {

			//session=sessionFactory.openSession();
			//session=new HibernateUtil().getSession();
			session = getSession();
			//session=new HibernateUtil().getSession();
			transaction=session.beginTransaction();
//	employee=session.get(Employee.class,employee.getId());
			
			if(ids.length!=0)
			{
				for(int a:ids)
			    {
					employee1=session.get(Employee.class,a);
					if(employee1!=null)
					session.delete(employee1);
					else
						flag=false;
				}
			}
			

			transaction.commit();

		} catch (Exception e) {
                flag=false;
			transaction.rollback();
			e.printStackTrace();
		}
		
		return flag;
	}
	
	

}
