package com.evry.employees.employeesdemo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateExample {
	
	public static void main(String[] args)
	{
		Date date=new Date();
		SimpleDateFormat df=new SimpleDateFormat("dd-MM-yyyy");
		String date1=df.format(date);
		
		System.out.println(date);
		System.out.println(date1);
	}

}
