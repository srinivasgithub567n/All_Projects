package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * 
 * @author EI11321
 *
 */
public class EndDateValidator implements Validator {
	private static final Logger logger = Logger.getLogger(StartDateValidator.class);
	public static String startDate;
	FacesMessage message = new FacesMessage();

	/**
	 * this method is used to apply validation for end date where it checks whether end date entered is equal to or after the 
	 * start date . if not matching with the condition , validatioin error is thrown back.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String endDate = (String) value;
		logger.info("*******Entered end date is :" + endDate);
		int endDateDay = 0;
		int endDateMonth = 0;
		int endDateYear = 0;
		int startDateDay = 0;
		int startDateMonth = 0;
		int startDateYear = 0;
		String[] endDateArray = endDate.split("-");
		if (endDateArray.length == 3 && !(endDateArray[0].isEmpty()) && !(endDateArray[1].isEmpty())
				&& !(endDateArray[2].isEmpty())) {
			endDateDay = Integer.parseInt(endDateArray[0]);
			endDateMonth = Integer.parseInt(endDateArray[1]);
			endDateYear = Integer.parseInt(endDateArray[2]);
		}
		String[] startDateArray = startDate.split("-");
		if (startDateArray.length == 3 && !(startDateArray[0].isEmpty()) && !(startDateArray[1].isEmpty())
				&& !(startDateArray[2].isEmpty())) {
			startDateDay = Integer.parseInt(startDateArray[0]);
			startDateMonth = Integer.parseInt(startDateArray[1]);
			startDateYear = Integer.parseInt(startDateArray[2]);
		}
		logger.info(" **** Day , Month and Year of start date are :" + startDateDay + "," + startDateMonth + ","
				+ startDateYear);
		logger.info(
				" **** Day , Month and Year of end date  are  :" + endDateDay + "," + endDateMonth + "," + endDateYear);
		if (endDateYear >= startDateYear) {
			if (endDateYear == startDateYear) {
				if (endDateMonth >= startDateMonth) {
					if (endDateMonth == startDateMonth) {
						if (endDateDay < startDateDay) {
							message.setSummary(
									i18nResourceBundle.getString("app.employee.validation.enddate.validity"));
							throw new ValidatorException(message);
						}
					}
				} else {
					message.setSummary(i18nResourceBundle.getString("app.employee.validation.enddate.validity"));
					throw new ValidatorException(message);
				}
			}
		} else {
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.enddate.validity"));
			throw new ValidatorException(message);
		}
	}

	public static void sendStartdate(String startDateReceived) {
		startDate = startDateReceived;
	}
}
