package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * 
 * @author EI11321
 *
 */
public class DateOfJoiningValidator implements Validator {
	private static final Logger logger = Logger.getLogger(DateOfJoiningValidator.class);
	public static String dateOfBirth;

	/**
	 * this method validates the Date Of Joining with Date of Birth passed to it to check if years of difference is 20 years or more than it between them.
	 * 
	 * if not validation error is thrown . else it's allowed to move further.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		String dateOfJoining = (String) value;
		int dateOfJoiningYear = 0;
		int dateOfBirthYear = 0;
		logger.info("**** Entered date of joining is : " + dateOfJoining);
		StartDateValidator.sendDateOfJoining(dateOfJoining);
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		FacesMessage message = new FacesMessage();
		logger.info("********* Received date of birth in date of joining validation method is :" + dateOfBirth);
		if (dateOfJoining != null) {
			String[] dateOfJoiningArray = dateOfJoining.split("-");
			if (dateOfJoiningArray.length == 3 && !(dateOfJoiningArray[2].isEmpty()))
				dateOfJoiningYear = Integer.parseInt(dateOfJoiningArray[2]);
		}
		if (dateOfBirth != null) {
			String[] dateOfBirthArray = dateOfBirth.split("-");
			if (dateOfBirthArray.length == 3 && !(dateOfBirthArray[2].isEmpty()))
				dateOfBirthYear = Integer.parseInt(dateOfBirthArray[2]);
		}
		logger.info("**** Date of Birth and joining years are :" + dateOfBirthYear + " " + dateOfJoiningYear);
		if (dateOfBirth != null) {
			if (dateOfBirthYear < dateOfJoiningYear) {
				int yearsDifference = dateOfJoiningYear - dateOfBirthYear;
				logger.info("***** years difference is :" + yearsDifference);
				if (yearsDifference < 20) {
					message.setSummary(i18nResourceBundle.getString("app.employee.validation.dateofbirth.validity"));
					sendDateOfBirth(null);
					logger.info("********* Date of Birth after execution of Date of Joining is :" + dateOfBirth);
					throw new ValidatorException(message);
				}
			} else {
				message.setSummary(i18nResourceBundle.getString("app.employee.validation.dateofbirth.validity"));
				sendDateOfBirth(null);
				logger.info("********* Date of Birth after execution of Date of Joining is :" + dateOfBirth);
				throw new ValidatorException(message);
			}
		}
	}

	public static void sendDateOfBirth(String dateOfBirthReceived) {
		dateOfBirth = dateOfBirthReceived;
	}
}
