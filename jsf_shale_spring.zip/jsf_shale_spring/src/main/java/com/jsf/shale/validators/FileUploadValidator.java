package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;
import org.apache.myfaces.custom.fileupload.UploadedFile;
import com.jsf.shale.ImageServlet;

/**
 * 
 * @author EI11321
 *
 */
public class FileUploadValidator implements Validator {
	private static final Logger logger = Logger.getLogger(FileUploadValidator.class);

	/**
	 * this method applies the validation on uploaded file.
	 * if the uploaded file is not of type ".jpg or .png or .gif or .tif" , validation error is thrown back.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		FacesMessage message = new FacesMessage();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		UploadedFile upLoadedFile = (UploadedFile) value;
		String uploadedFileName = upLoadedFile.getName();
		logger.info("**** Name of the file uploaded is :" + uploadedFileName);
		if (!(uploadedFileName.contains(".jpg")) && !(uploadedFileName.contains(".png"))
				&& !(uploadedFileName.contains(".tif")) && !(uploadedFileName.contains(".gif"))) {
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.photo.upload.wrong.file"));
			ImageServlet.sendImageBytes(null);
			throw new ValidatorException(message);
		}
	}
}
