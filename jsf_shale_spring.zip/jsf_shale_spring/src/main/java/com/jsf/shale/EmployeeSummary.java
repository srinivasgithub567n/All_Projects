package com.jsf.shale;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.faces.component.html.HtmlDataTable;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.jsf.shale.model.DropDownList;
import com.jsf.shale.model.Employee;
import com.jsf.shale.model.PromotionHistory;
import com.jsf.shale.service.EmployeeService;
import com.jsf.shale.util.DTOComparator;
import com.jsf.shale.util.OperationStatus;

/**
 * 
 * @author EI11321
 * 
 *  'EmployeeSummary' class is a managed bean which is bound to the JFS view 'employee_summary.jsp'
 * 
 *
 */
public class EmployeeSummary {
	private static final Logger logger = Logger.getLogger(EmployeeSummary.class);
	private List<Employee> activeEmployeesBFS;
	private List<Employee> inactiveEmployeesBFS;
	private List<Employee> activeEmployeesIAH;
	private List<Employee> inactiveEmployeesIAH;
	private List<Employee> activeEmployeesRetail;
	private List<Employee> inactiveEmployeesRetail;
	private Map<Long, Boolean> selectedIds = new HashMap<Long, Boolean>();
	private EmployeeService employeeService;
	private List<DropDownList> dropDownList;
	private List<Employee> employeeListBackup;
	private List<PromotionHistory> promotionListOfEmployee;
	private boolean sortAscending = true;
	private String sortField = null;
	private boolean renderBFSA = true;
	private boolean renderBFSI = true;
	private boolean renderIAHA = true;
	private boolean renderIAHI = true;
	private boolean renderRA = true;
	private boolean renderRI = true;
	private int count;

	/**
	 * 
	 * @return count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * 
	 * @param count
	 *   count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * 
	 * @return renderBFSA
	 */
	public boolean isRenderBFSA() {
		return renderBFSA;
	}

	/**
	 * 
	 * @param renderBFSA
	 * renderBFSA to set
	 *  
	 */
	public void setRenderBFSA(boolean renderBFSA) {
		this.renderBFSA = renderBFSA;
	}

	/**
	 * 
	 * @return renderBFSI
	 */
	public boolean isRenderBFSI() {
		return renderBFSI;
	}

	/**
	 * 
	 * @param renderBFSI
	 *renderBFSI to set
	 */
	public void setRenderBFSI(boolean renderBFSI) {
		this.renderBFSI = renderBFSI;
	}

	/**
	 * 
	 * @return renderIAHA
	 */
	public boolean isRenderIAHA() {
		return renderIAHA;
	}

	/**
	 * 
	 * @param renderIAHA
	 *  renderIAHA to set
	 */
	public void setRenderIAHA(boolean renderIAHA) {
		this.renderIAHA = renderIAHA;
	}

	/**
	 * 
	 * @return renderIAHI
	 */
	public boolean isRenderIAHI() {
		return renderIAHI;
	}

	/**
	 * 
	 * @param renderIAHI
	 *  renderIAHI to set
	 */
	public void setRenderIAHI(boolean renderIAHI) {
		this.renderIAHI = renderIAHI;
	}

	/**
	 * 
	 * @return renderRA
	 */
	public boolean isRenderRA() {
		return renderRA;
	}

	/**
	 * 
	 * @param renderRA
	 * 
	 * renderRA to set
	 */
	public void setRenderRA(boolean renderRA) {
		this.renderRA = renderRA;
	}

	/**
	 * 
	 * @return renderRI
	 */
	public boolean isRenderRI() {
		return renderRI;
	}

	/**
	 * 
	 * @param renderRI
	 *  renderRI to set
	 */
	public void setRenderRI(boolean renderRI) {
		this.renderRI = renderRI;
	}

	/**
	 * 
	 * @return sortField
	 */
	public String getSortField() {
		return sortField;
	}

	/**
	 * 
	 * @param sortField
	 * sortField to set
	 */
	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	/**
	 * 
	 * @return sortAscending
	 */
	public boolean isSortAscending() {
		return sortAscending;
	}

	/**
	 * 
	 * @param sortAscending
	 *  sortAscending to set
	 */
	public void setSortAscending(boolean sortAscending) {
		this.sortAscending = sortAscending;
	}

	/**
	 * 
	 * @return promotionListOfEmployee
	 */
	public List<PromotionHistory> getPromotionListOfEmployee() {
		return promotionListOfEmployee;
	}

	/**
	 * 
	 * @param promotionListOfEmployee
	 * 
	 *  promotionListOfEmployee to set
	 */
	public void setPromotionListOfEmployee(List<PromotionHistory> promotionListOfEmployee) {
		this.promotionListOfEmployee = promotionListOfEmployee;
	}

	/**
	 * @return the employeeListBackup
	 */
	public List<Employee> getEmployeeListBackup() {
		return employeeListBackup;
	}

	/**
	 * @param employeeListBackup
	 *            the employeeListBackup to set
	 */
	public void setEmployeeListBackup(List<Employee> employeeListBackup) {
		this.employeeListBackup = employeeListBackup;
	}

	/**
	 * @return the dropDownList
	 */
	public List<DropDownList> getDropDownList() {
		return dropDownList;
	}

	/**
	 * @param dropDownList
	 *            the dropDownList to set
	 */
	public void setDropDownList(List<DropDownList> dropDownList) {
		this.dropDownList = dropDownList;
	}

	/**
	 * @return the employeeService
	 */
	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	/**
	 * @param employeeService
	 *            the employeeService to set
	 */
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	/**
	 * @return the selectedIds
	 */
	public Map<Long, Boolean> getSelectedIds() {
		return selectedIds;
	}

	/**
	 * @param selectedIds
	 *            the selectedIds to set
	 */
	public void setSelectedIds(Map<Long, Boolean> selectedIds) {
		this.selectedIds = selectedIds;
	}

	/**
	 * @return the activeEmployeesBFS
	 */
	public List<Employee> getActiveEmployeesBFS() {
		int count = 1;
		if (this.getCount() == 0) {
			this.getEmployeeList();
			this.setCount(count);
			logger.info("****Employee summary current object is sent****");
			EmployeeEnrollment.sendEmployeeSummaryObject(this);
		}
		return activeEmployeesBFS;
	}

	/**
	 * @param activeEmployeesBFS
	 *            the activeEmployeesBFS to set
	 */
	public void setActiveEmployeesBFS(List<Employee> activeEmployeesBFS) {
		this.activeEmployeesBFS = activeEmployeesBFS;
	}

	/**
	 * @return the inactiveEmployeesBFS
	 */
	public List<Employee> getInactiveEmployeesBFS() {
		return inactiveEmployeesBFS;
	}

	/**
	 * @param inactiveEmployeesBFS
	 *            the inactiveEmployeesBFS to set
	 */
	public void setInactiveEmployeesBFS(List<Employee> inactiveEmployeesBFS) {
		this.inactiveEmployeesBFS = inactiveEmployeesBFS;
	}

	/**
	 * @return the activeEmployeesIAH
	 */
	public List<Employee> getActiveEmployeesIAH() {
		return activeEmployeesIAH;
	}

	/**
	 * @param activeEmployeesIAH
	 *            the activeEmployeesIAH to set
	 */
	public void setActiveEmployeesIAH(List<Employee> activeEmployeesIAH) {
		this.activeEmployeesIAH = activeEmployeesIAH;
	}

	/**
	 * @return the inactiveEmployeesIAH
	 */
	public List<Employee> getInactiveEmployeesIAH() {
		return inactiveEmployeesIAH;
	}

	/**
	 * @param inactiveEmployeesIAH
	 *            the inactiveEmployeesIAH to set
	 */
	public void setInactiveEmployeesIAH(List<Employee> inactiveEmployeesIAH) {
		this.inactiveEmployeesIAH = inactiveEmployeesIAH;
	}

	/**
	 * @return the activeEmployeesRetail
	 */
	public List<Employee> getActiveEmployeesRetail() {
		return activeEmployeesRetail;
	}

	/**
	 * @param activeEmployeesRetail
	 *            the activeEmployeesRetail to set
	 */
	public void setActiveEmployeesRetail(List<Employee> activeEmployeesRetail) {
		this.activeEmployeesRetail = activeEmployeesRetail;
	}

	/**
	 * @return the inactiveEmployeesRetail
	 */
	public List<Employee> getInactiveEmployeesRetail() {
		return inactiveEmployeesRetail;
	}

	/**
	 * @param inactiveEmployeesRetail
	 *            the inactiveEmployeesRetail to set
	 */
	public void setInactiveEmployeesRetail(List<Employee> inactiveEmployeesRetail) {
		this.inactiveEmployeesRetail = inactiveEmployeesRetail;
	}

	/**
	 *  this method is to retrieve the list of employees and distribute it  to corresponding panel in JSF view 'employee_summary.jsp'
	 *  
	 *  based on the department and status of employee ( active or inactive ) 
	 *  
	 *  before distributing the list , conversion happens from Date type dates to string type dates and as well as drop down id's to Labels.
	 *  
	 *  if the size of the list of particular department is zero , 'no records available' message is shown in JSF view else 
	 *  
	 *  table is displayed with existing list.
	 */
	public void getEmployeeList() {
		try {
		List<Employee> activeEmployeesBFS = new ArrayList();
		List<Employee> inactiveEmployeesBFS = new ArrayList();
		List<Employee> activeEmployeesIAH = new ArrayList();
		List<Employee> inactiveEmployeesIAH = new ArrayList();
		List<Employee> activeEmployeesRetails = new ArrayList();
		List<Employee> inactiveEmployeesRetail = new ArrayList();
		employeeListBackup = employeeService.getEmployeeList();
		this.setDropDownList(employeeService.getDropDownList());
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		logger.info("*****************Employee records are************************** :");
		for (Employee employee : this.getEmployeeListBackup()) {
			if (employee.getUploadedImage() != null) {
				employee.setUploadedImage(Base64.decodeBase64(employee.getUploadedImage()));
			}
			employee.setDateOfBirthS(dateFormat.format(employee.getDateOfBirth()));
			employee.setDateOfJoiningS(dateFormat.format(employee.getDateOfJoining()));
			employee.setStartDateS(dateFormat.format(employee.getStartDate()));
			if (employee.getEndDate() != null) {
				employee.setEndDateS(dateFormat.format(employee.getEndDate()));
			}
			logger.info(employee.getId() + "," + employee.getDateOfBirth() + "," + employee.getDateOfJoining() + ","
					+ employee.getDepartment() + "," + employee.getDesignation() + "," + employee.getEndDate() + ","
					+ employee.getGender() + "," + employee.getLocation() + "," + employee.getManagerStatus() + ","
					+ employee.getName() + "," + employee.getPrimarySkill() + "," + employee.getReportTo() + ","
					+ employee.getStartDate() + "," + employee.getStatus() + "," + employee.getUploadedImage()
					+ ", and size of the promotion list is :" + employee.getPromotionList().size());
			for (DropDownList dropDownItem : this.getDropDownList()) {
				if (employee.getDepartment().equals(String.valueOf(dropDownItem.getItemId()))) {
					employee.setDepartment(dropDownItem.getItemLabel());
				} else if (employee.getReportTo().equals(String.valueOf(dropDownItem.getItemId()))) {
					employee.setReportTo(dropDownItem.getItemLabel());
				} else if (employee.getPrimarySkill().equals(String.valueOf(dropDownItem.getItemId()))) {
					employee.setPrimarySkill(dropDownItem.getItemLabel());
				} else if (employee.getLocation().equals(String.valueOf(dropDownItem.getItemId()))) {
					employee.setLocation(dropDownItem.getItemLabel());
				} else if (employee.getDesignation().equals(String.valueOf(dropDownItem.getItemId()))) {
					employee.setDesignation(dropDownItem.getItemLabel());
				}
			}
			if (employee.getDepartment().equalsIgnoreCase("Banking And Finance System")) {
				logger.info("***** Department and Status of the Employee is :" + employee.getDepartment() + ","
						+ employee.getStatus());
				if (employee.getStatus().equalsIgnoreCase("active")) {
					activeEmployeesBFS.add(employee);
				} else {
					inactiveEmployeesBFS.add(employee);
				}
			} else if (employee.getDepartment().equalsIgnoreCase("Insurance And Health")) {
				logger.info("***** Department and Status of the Employee is :" + employee.getDepartment() + ","
						+ employee.getStatus());
				if (employee.getStatus().equalsIgnoreCase("active")) {
					activeEmployeesIAH.add(employee);
				} else {
					inactiveEmployeesIAH.add(employee);
				}
			} else if (employee.getDepartment().equalsIgnoreCase("Retail")) {
				logger.info("***** Department and Status of the Employee is :" + employee.getDepartment() + ","
						+ employee.getStatus());
				if (employee.getStatus().equalsIgnoreCase("active")) {
					activeEmployeesRetails.add(employee);
				} else {
					inactiveEmployeesRetail.add(employee);
				}
			}
		}
		for (Employee employee : this.getEmployeeListBackup()) {
			List<SelectItem> promotionItemList = new LinkedList<SelectItem>();
			for (PromotionHistory promotion : employee.getPromotionList()) {
				for (DropDownList dropDownItem : this.getDropDownList()) {
					if (promotion.getDesignation().equals(String.valueOf(dropDownItem.getItemId()))) {
						SelectItem item = new SelectItem(String.valueOf(dropDownItem.getItemId()),
								dropDownItem.getItemLabel());
						promotionItemList.add(item);
					}
				}
			}
			employee.setPromotionItems(promotionItemList);
		}
		if (activeEmployeesBFS.size() == 0) {
			this.setRenderBFSA(false);
		} else {
			this.setActiveEmployeesBFS(activeEmployeesBFS);
			this.setRenderBFSA(true);
		}
		if (inactiveEmployeesBFS.size() == 0) {
			this.setRenderBFSI(false);
		} else {
			this.setInactiveEmployeesBFS(inactiveEmployeesBFS);
			this.setRenderBFSI(true);
		}
		if (activeEmployeesIAH.size() == 0) {
			this.setRenderIAHA(false);
		} else {
			this.setActiveEmployeesIAH(activeEmployeesIAH);
			this.setRenderIAHA(true);
		}
		if (inactiveEmployeesIAH.size() == 0) {
			this.setRenderIAHI(false);
		} else {
			this.setInactiveEmployeesIAH(inactiveEmployeesIAH);
			this.setRenderIAHI(true);
		}
		if (activeEmployeesRetails.size() == 0) {
			this.setRenderRA(false);
		} else {
			this.setActiveEmployeesRetail(activeEmployeesRetails);
			this.setRenderRA(true);
		}
		if (inactiveEmployeesRetail.size() == 0) {
			this.setRenderRI(false);
		} else {
			this.setInactiveEmployeesRetail(inactiveEmployeesRetail);
			this.setRenderRI(true);
		}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException is raised", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception exception) {
			logger.error("Exception is raised ", exception);
		}
	}

	/*** Pagination code for Table 1 - BFS active employees ***/
	HtmlDataTable dataTableBFSA = new HtmlDataTable();

	// to get to the first page of pagination
	public void pageFirstBFSA() {
		dataTableBFSA.setFirst(0);
	}

	// to get to the previous page of pagination
	public void pagePreviousBFSA() {
		dataTableBFSA.setFirst(dataTableBFSA.getFirst() - dataTableBFSA.getRows());
	}

	// to get to the next page of pagination
	public void pageNextBFSA() {
		dataTableBFSA.setFirst(dataTableBFSA.getFirst() + dataTableBFSA.getRows());
	}

	// to get to the last page of pagination
	public void pageLastBFSA() {
		int count = dataTableBFSA.getRowCount();
		int rows = dataTableBFSA.getRows();
		dataTableBFSA.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// to get the current page number
	public int getCurrentPageBFSA() {
		int rows = dataTableBFSA.getRows();
		int first = dataTableBFSA.getFirst();
		int count = dataTableBFSA.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// to get the total no of pages
	public int getTotalPagesBFSA() {
		int rows = dataTableBFSA.getRows();
		int count = dataTableBFSA.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTableBFSA() {
		return dataTableBFSA;
	}

	public void setDataTableBFSA(HtmlDataTable dataTable) {
		this.dataTableBFSA = dataTable;
	}

	/*** Pagination code for Table2- BFS inactive employees ***/
	HtmlDataTable dataTableBFSI = new HtmlDataTable();

	// to get to the first page of pagination
	public void pageFirstBFSI() {
		dataTableBFSI.setFirst(0);
	}

	// to get to the previous page of pagination
	public void pagePreviousBFSI() {
		dataTableBFSI.setFirst(dataTableBFSI.getFirst() - dataTableBFSI.getRows());
	}

	// to get to the next page of pagination
	public void pageNextBFSI() {
		dataTableBFSI.setFirst(dataTableBFSI.getFirst() + dataTableBFSI.getRows());
	}

	// to get to the last page of pagination
	public void pageLastBFSI() {
		int count = dataTableBFSI.getRowCount();
		int rows = dataTableBFSI.getRows();
		dataTableBFSI.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// to get the current page number
	public int getCurrentPageBFSI() {
		int rows = dataTableBFSI.getRows();
		int first = dataTableBFSI.getFirst();
		int count = dataTableBFSI.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// to get the total no of pages
	public int getTotalPagesBFSI() {
		int rows = dataTableBFSI.getRows();
		int count = dataTableBFSI.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTableBFSI() {
		return dataTableBFSI;
	}

	public void setDataTableBFSI(HtmlDataTable dataTable) {
		this.dataTableBFSI = dataTable;
	}

	/*** Pagination code for Table3- IAH active employees ***/
	HtmlDataTable dataTableIAHA = new HtmlDataTable();

	// to get to the first page of pagination
	public void pageFirstIAHA() {
		dataTableIAHA.setFirst(0);
	}

	// to get to the previous page of pagination
	public void pagePreviousIAHA() {
		dataTableIAHA.setFirst(dataTableIAHA.getFirst() - dataTableIAHA.getRows());
	}

	// to get to the next page of pagination
	public void pageNextIAHA() {
		dataTableIAHA.setFirst(dataTableIAHA.getFirst() + dataTableIAHA.getRows());
	}

	// to get to the last page of pagination
	public void pageLastIAHA() {
		int count = dataTableIAHA.getRowCount();
		int rows = dataTableIAHA.getRows();
		dataTableIAHA.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// to get the current page number
	public int getCurrentPageIAHA() {
		int rows = dataTableIAHA.getRows();
		int first = dataTableIAHA.getFirst();
		int count = dataTableIAHA.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// to get the total no of pages
	public int getTotalPagesIAHA() {
		int rows = dataTableIAHA.getRows();
		int count = dataTableIAHA.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTableIAHA() {
		return dataTableIAHA;
	}

	public void setDataTableIAHA(HtmlDataTable dataTable) {
		this.dataTableIAHA = dataTable;
	}

	/*** Pagination code for Table4- IAH inactive employees ***/
	HtmlDataTable dataTableIAHI = new HtmlDataTable();

	// to get to the first page of pagination
	public void pageFirstIAHI() {
		dataTableIAHI.setFirst(0);
	}

	// to get to the previous page of pagination
	public void pagePreviousIAHI() {
		dataTableIAHI.setFirst(dataTableIAHI.getFirst() - dataTableIAHI.getRows());
	}

	// to get to the next page of pagination
	public void pageNextIAHI() {
		dataTableIAHI.setFirst(dataTableIAHI.getFirst() + dataTableIAHI.getRows());
	}

	// to get to the last page of pagination
	public void pageLastIAHI() {
		int count = dataTableIAHI.getRowCount();
		int rows = dataTableIAHI.getRows();
		dataTableIAHI.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// to get the current page number
	public int getCurrentPageIAHI() {
		int rows = dataTableIAHI.getRows();
		int first = dataTableIAHI.getFirst();
		int count = dataTableIAHI.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// to get the total no of pages
	public int getTotalPagesIAHI() {
		int rows = dataTableIAHI.getRows();
		int count = dataTableIAHI.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTableIAHI() {
		return dataTableIAHI;
	}

	public void setDataTableIAHI(HtmlDataTable dataTable) {
		this.dataTableIAHI = dataTable;
	}

	/*** Pagination code for Table5- Retail active employees ***/
	HtmlDataTable dataTableRetail = new HtmlDataTable();

	// to get to the first page of pagination
	public void pageFirstRetail() {
		dataTableRetail.setFirst(0);
	}

	// to get to the previous page of pagination
	public void pagePreviousRetail() {
		dataTableRetail.setFirst(dataTableRetail.getFirst() - dataTableRetail.getRows());
	}

	// to get to the next page of pagination
	public void pageNextRetail() {
		dataTableRetail.setFirst(dataTableRetail.getFirst() + dataTableRetail.getRows());
	}

	// to get to the last page of pagination
	public void pageLastRetail() {
		int count = dataTableRetail.getRowCount();
		int rows = dataTableRetail.getRows();
		dataTableRetail.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// to get the current page number
	public int getCurrentPageRetail() {
		int rows = dataTableRetail.getRows();
		int first = dataTableRetail.getFirst();
		int count = dataTableRetail.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// to get the total no of pages
	public int getTotalPagesRetail() {
		int rows = dataTableRetail.getRows();
		int count = dataTableRetail.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTableRetail() {
		return dataTableRetail;
	}

	public void setDataTableRetail(HtmlDataTable dataTable) {
		this.dataTableRetail = dataTable;
	}

	/*** Pagination code for Table6- Retail inactive employees ***/
	HtmlDataTable dataTableRetailI = new HtmlDataTable();

	// to get to the first page of pagination
	public void pageFirstRetailI() {
		dataTableRetailI.setFirst(0);
	}

	// to get to the previous page of pagination
	public void pagePreviousRetailI() {
		dataTableRetailI.setFirst(dataTableRetailI.getFirst() - dataTableRetailI.getRows());
	}

	// to get to the next page of pagination
	public void pageNextRetailI() {
		dataTableRetailI.setFirst(dataTableRetailI.getFirst() + dataTableRetailI.getRows());
	}

	// to get to the last page of pagination
	public void pageLastRetailI() {
		int count = dataTableRetailI.getRowCount();
		int rows = dataTableRetailI.getRows();
		dataTableRetailI.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// to get the current page number
	public int getCurrentPageRetailI() {
		int rows = dataTableRetailI.getRows();
		int first = dataTableRetailI.getFirst();
		int count = dataTableRetailI.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// to get the total no of pages
	public int getTotalPagesRetailI() {
		int rows = dataTableRetailI.getRows();
		int count = dataTableRetailI.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTableRetailI() {
		return dataTableRetailI;
	}

	public void setDataTableRetailI(HtmlDataTable dataTable) {
		this.dataTableRetailI = dataTable;
	}

	/**
	 * 
	 * @param employee
	 * @return the String
	 * 
	 * this method extracts the list of promotions of employee from corresponding employee object to display in the pop up window .
	 */
	public String retrievePromotionList(Employee employee) {
		logger.info("***** Entered into retrievePromotionList() ********  ");
		//this.setPromotionListOfEmployee(null);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		for (PromotionHistory promotion : employee.getPromotionList()) {
			if (promotion.getStartDate() != null)
				promotion.setStartDateS(dateFormat.format(promotion.getStartDate()));
			if (promotion.getEndDate() != null)
				promotion.setEndDateS(dateFormat.format(promotion.getEndDate()));
			else
				promotion.setEndDateS("N/A");
			for (DropDownList dropDownItem : this.getDropDownList()) {
				if (promotion.getDesignation().equals(String.valueOf(dropDownItem.getItemId()))) {
					promotion.setDesignation(dropDownItem.getItemLabel());
				}
			}
		}
		this.setPromotionListOfEmployee(employee.getPromotionList());
		logger.info("**** Assigned the promotion list *********");
		return OperationStatus.SUCCESS;
	}

	// to sort the data tables of employee summary
	public void sortDataList(ActionEvent event) {
		logger.info("Entered into sortDataList() method of 'User' managed bean");
		String sortFieldAttribute = getAttribute(event, "sortField");
		String department = getAttribute(event, "department");
		logger.info("Sorting field chosen based on which data needs to be sorted and department are   :"
				+ sortFieldAttribute + " " + department);
		// Get and set sort field and sort order.
		if (sortField != null && sortField.equals(sortFieldAttribute)) {
			sortAscending = !sortAscending;
		} else {
			sortField = sortFieldAttribute;
			sortAscending = true;
		}
		if (department.equalsIgnoreCase("banking-active")) {
			logger.info("Users list before sorting :" + this.getActiveEmployeesBFS());
			// Sort results.
			if (sortField != null) {
				Collections.sort(this.getActiveEmployeesBFS(), new DTOComparator(sortField, sortAscending));
			}
			logger.info("Users list after sorting :" + this.activeEmployeesBFS);
		} else if (department.equalsIgnoreCase("banking-inactive")) {
			logger.info("Users list before sorting :" + this.getInactiveEmployeesBFS());
			// Sort results.
			if (sortField != null) {
				Collections.sort(this.getInactiveEmployeesBFS(), new DTOComparator(sortField, sortAscending));
			}
			logger.info("Users list after sorting :" + this.getInactiveEmployeesBFS());
		} else if (department.equalsIgnoreCase("insurance-active")) {
			logger.info("Users list before sorting :" + this.getActiveEmployeesIAH());
			// Sort results.
			if (sortField != null) {
				Collections.sort(this.getActiveEmployeesIAH(), new DTOComparator(sortField, sortAscending));
			}
			logger.info("Users list after sorting :" + this.getActiveEmployeesIAH());
		} else if (department.equalsIgnoreCase("insurance-inactive")) {
			logger.info("Users list before sorting :" + this.getInactiveEmployeesIAH());
			// Sort results.
			if (sortField != null) {
				Collections.sort(this.getInactiveEmployeesIAH(), new DTOComparator(sortField, sortAscending));
			}
			logger.info("Users list after sorting :" + this.getInactiveEmployeesIAH());
		} else if (department.equalsIgnoreCase("retail-active")) {
			logger.info("Users list before sorting :" + this.getActiveEmployeesRetail());
			// Sort results.
			if (sortField != null) {
				Collections.sort(this.getActiveEmployeesRetail(), new DTOComparator(sortField, sortAscending));
			}
			logger.info("Users list after sorting :" + this.getActiveEmployeesRetail());
		} else {
			logger.info("Users list before sorting :" + this.getInactiveEmployeesRetail());
			// Sort results.
			if (sortField != null) {
				Collections.sort(this.getInactiveEmployeesRetail(), new DTOComparator(sortField, sortAscending));
			}
			logger.info("Users list after sorting :" + this.getInactiveEmployeesRetail());
		}
	}

	// to retrieve the values of the attributes passed by action event to sort the data table based on the particular column
	private static String getAttribute(ActionEvent event, String name) {
		String value = (String) event.getComponent().getAttributes().get(name);
		return value;
	}
}
