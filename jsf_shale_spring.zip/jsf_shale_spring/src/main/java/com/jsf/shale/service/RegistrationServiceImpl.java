package com.jsf.shale.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jsf.shale.Login;
import com.jsf.shale.model.UserInfo;
import com.jsf.shale.util.HttpDeleteWithBody;
import com.jsf.shale.util.OperationStatus;
import com.jsf.shale.util.SessionContext;

/**
 * 
 * @author srinivasa.nayana
 *
 */
@Service
public class RegistrationServiceImpl implements RegistrationService {
	private static final Logger logger = Logger.getLogger(RegistrationServiceImpl.class);

	/**
	 * @param userInfo
	 *            is accepted to add the newly registered user to the DB table
	 *            'customer_details'
	 * @return String which represents the status of creation of user
	 * 
	 *         this method consumes the restful web service to add the new user
	 */
	public String addUser(UserInfo userInfo) {
		logger.info("Entered into addUser() method");
		String userCreationStatus = null;
		try {
			if (userInfo != null) {
				logger.info("Details of user to be added :" + userInfo);
				String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/addUser";
				CloseableHttpClient httpClient = HttpClients.createDefault();
				HttpPost httpRequest = new HttpPost(url);
				JSONObject json = new JSONObject();
				json.put("firstName", userInfo.getFirstName());
				json.put("lastName", userInfo.getLastName());
				json.put("emailId", userInfo.getEmailId());
				json.put("mobileNo", userInfo.getMobileNo());
				json.put("password", userInfo.getPassword());
				StringEntity params = new StringEntity(json.toString(), "UTF-8");
				logger.info("User Details to be added in JSON format :" + params);
				httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
				httpRequest.addHeader("charset", "UTF-8");
				httpRequest.setEntity(params);
				HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
				logger.info("Http Response is :" + httpResponse.toString());
				int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
				logger.info("Http status code is :" + httpStatusCode);
				String httpResponseBody = EntityUtils.toString(httpResponse.getEntity());
				FacesContext context = FacesContext.getCurrentInstance();
				ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
				if (httpStatusCode == 200 && httpResponseBody.equals(OperationStatus.SUCCESS)) {
					userCreationStatus = httpResponseBody;
					context.addMessage(null, new FacesMessage(i18nResourceBundle.getString("method.adduser.success")));
				} else if (httpStatusCode == 500) {
					userCreationStatus = OperationStatus.FAILURE;
					context.addMessage(null, new FacesMessage(i18nResourceBundle.getString("method.adduser.failure")));
				} else {
					userCreationStatus = OperationStatus.INVALID;
					context.addMessage(null,
							new FacesMessage(i18nResourceBundle.getString("method.adduser.email.existence")));
				}
			} else {
				throw new NullPointerException("User details are not passed to create");
			}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException Occured", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception ex) {
			logger.error("Exception Occured ", ex);
		}
		return userCreationStatus;
	}

	/**
	 * @param loginCredentials
	 *            is accepts which contains the user credentials such email and
	 *            password
	 * @return UserInfo object which is used to retrieve and set the user first name
	 *         as welcome title.
	 * 
	 *         this method consumes the restful web service to authenticate the user
	 *         who is logged in
	 */
	public UserInfo loginVerify(Login loginCredentials) {
		logger.info("Entered into loginVerify() method");
		UserInfo loggedInCustomer = null;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/loginVerify";
		logger.info("Login email received  " + loginCredentials.getEmailId());
		try {
			if (loginCredentials != null) {
				logger.info("Login email received  " + loginCredentials.getEmailId());
				CloseableHttpClient httpClient = HttpClients.createDefault();
				HttpPost httpRequest = new HttpPost(url);
				JSONObject json = new JSONObject();
				json.put("emailId", loginCredentials.getEmailId());
				json.put("password", loginCredentials.getPassword());
				StringEntity params = new StringEntity(json.toString(), "UTF-8");
				logger.info("login credentials in JSON format :" + params);
				httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
				httpRequest.addHeader("charset", "UTF-8");
				httpRequest.setEntity(params);
				HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
				int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
				logger.info("Http Response is :" + httpResponse.toString());
				logger.info("Http status code is : " + httpStatusCode);
				if (httpStatusCode == 200) {
					HttpEntity entity = httpResponse.getEntity();
					String jsonResponse = EntityUtils.toString(entity);
					logger.info("Http Response body in JSOON fomrat :" + jsonResponse);
					ObjectMapper mapper = new ObjectMapper();
					loggedInCustomer = mapper.readValue(jsonResponse, new TypeReference<UserInfo>() {
					});
					logger.info("Logged In customer details : " + loggedInCustomer);
					SessionContext.getInstance().getCurrentSessionn().setAttribute("user",
							loggedInCustomer.getFirstName() + " " + loggedInCustomer.getLastName());
				} else if (httpStatusCode == 500) {
					context.addMessage(null,
							new FacesMessage(i18nResourceBundle.getString("method.loginverify.failure")));
				} else {
					context.addMessage(null,
							new FacesMessage(i18nResourceBundle.getString("method.loginverify.invalid")));
				}
			} else {
				throw new NullPointerException("Login credentials are not passed to verify");
			}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException is raised", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception ex) {
			logger.error("Exception is  raised  ", ex);
		}
		return loggedInCustomer;
	}

	/**
	 * 
	 * @return List<UserInfo> which contains data of list of users.
	 * 
	 *         this method consumes the restful web service to retrieve the list of
	 *         users
	 */
	public List<UserInfo> getCustomers() {
		logger.info("Entered into getCustomers() method");
		List<UserInfo> customersList = null;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/customers";
		try {
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpGet httpRequest = new HttpGet(url);
			httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
			httpRequest.addHeader("charset", "UTF-8");
			HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
			int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
			logger.info("Http Response is : " + httpResponse);
			logger.info("Http status code is :" + httpStatusCode);
			if (httpStatusCode == 200) {
				HttpEntity entity = httpResponse.getEntity();
				logger.info("Http Response Body is :" + entity);
				String jsonResponse = EntityUtils.toString(entity);
				logger.info("Http Response body in JSON format :" + jsonResponse);
				ObjectMapper mapper = new ObjectMapper();
				customersList = mapper.readValue(jsonResponse, new TypeReference<List<UserInfo>>() {
				});
				logger.info("List of customers :" + customersList);
			} else if (httpStatusCode == 500) {
				context.addMessage(null, new FacesMessage(i18nResourceBundle.getString("method.loginverify.failure")));
			} else if (httpStatusCode == 409) {
				customersList = new ArrayList<UserInfo>();
			}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException is raised", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception exception) {
			logger.error("Exception is raised ", exception);
		}
		return customersList;
	}

	/**
	 * @param userInfo
	 *            which indicates the details of user which needs to be updated
	 * @return String which represents the status of user updation
	 * 
	 *         this method consumes the restful web service to update the user
	 *         details.
	 */
	public String updateCustomer(UserInfo userInfo) {
		logger.info("Entered into updateCustomer() method");
		logger.info("Details of user to be updated : " + userInfo);
		String userUpdationStatus = null;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/customers/" + userInfo.getId();
		try {
			if (userInfo != null) {
				CloseableHttpClient httpClient = HttpClients.createDefault();
				HttpPut httpRequest = new HttpPut(url);
				JSONObject json = new JSONObject();
				json.put("id", userInfo.getId());
				json.put("firstName", userInfo.getFirstName());
				json.put("lastName", userInfo.getLastName());
				json.put("emailId", userInfo.getEmailId());
				json.put("mobileNo", userInfo.getMobileNo());
				StringEntity params = new StringEntity(json.toString(), "UTF-8");
				logger.info("Http Request Body  : " + params);
				httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
				httpRequest.addHeader("charset", "UTF-8");
				httpRequest.setEntity(params);
				HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
				int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
				logger.info("Http Response is :" + httpResponse.toString());
				logger.info("Http Response statuc code is :" + httpStatusCode);
				String httpResponseBody = EntityUtils.toString(httpResponse.getEntity());
				// logger.info("status of user updation received from web servie is : "+status);
				if (httpStatusCode == 200 && httpResponseBody.equals(OperationStatus.SUCCESS)) {
					userUpdationStatus = OperationStatus.SUCCESS;
					context.addMessage(null,
							new FacesMessage(i18nResourceBundle.getString("method.updatecustomer.user") + ": '"
									+ userInfo.getEmailId() + "' "
									+ i18nResourceBundle.getString("method.updatecustomer.info")));
				} else {
					userUpdationStatus = OperationStatus.FAILURE;
					context.addMessage(null,
							new FacesMessage(i18nResourceBundle.getString("method.updatecustomer.failure")));
				}
			} else {
				throw new NullPointerException("User details are not passed to update");
			}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException is raised", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception ex) {
			logger.error("Error occured in updateCustomer() method ", ex);
		}
		return userUpdationStatus;
	}

	/**
	 * @param userInfo
	 *            which indicates the user to be deleted
	 * @return String which represents the status of the user deletion
	 * 
	 *         this method consumes the restful web service to delete the user
	 */
	public String deleteCustomer(UserInfo userInfo) {
		logger.info("Entered into deleteCustomer() method");
		logger.info("Details of user to be deleted : " + userInfo);
		String userDeletionStatus = null;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/customers/" + userInfo.getId();
		try {
			if (userInfo != null) {
				CloseableHttpClient httpClient = HttpClients.createDefault();
				HttpDelete httpRequest = new HttpDelete(url);
				HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
				int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
				logger.info("Http Response is :" + httpResponse.toString());
				logger.info("Http status code is : " + httpStatusCode);
				String httpResponseBody = EntityUtils.toString(httpResponse.getEntity());
				logger.info("status of user deletion from web service :" + userDeletionStatus);
				if (httpStatusCode == 200 && httpResponseBody.equals(OperationStatus.SUCCESS)) {
					if (this.getCustomers().size() == 0) {
						userDeletionStatus = OperationStatus.NO_DATA;
					} else {
						userDeletionStatus = OperationStatus.SUCCESS;
						context.addMessage(null,
								new FacesMessage(i18nResourceBundle.getString("method.updatecustomer.user") + " : '"
										+ userInfo.getEmailId() + "' "
										+ i18nResourceBundle.getString("method.deletecustomer.info")));
					}
				} else {
					userDeletionStatus = OperationStatus.FAILURE;
					context.addMessage(null,
							new FacesMessage(i18nResourceBundle.getString("method.deletecustomer.failure")));
				}
			} else {
				throw new NullPointerException("Customer Id is not passed to delete");
			}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException is raised", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception ex) {
			logger.error("Error occured in deleteCustomer() method ", ex);
		}
		return userDeletionStatus;
	}

	/**
	 * @param customerIds
	 *            which contains the user ids to delete the multiple users.
	 * @return String which represents the status of deletion of users.
	 * 
	 *         this method consumes restful web service to delete multiple users at
	 *         time
	 */
	public String deleteSelectedCustomers(int[] customerIds) {
		logger.info("Entered into deleteSelectedCustomers() method");
		logger.info("User ids to be deleted : " + customerIds);
		String usersDeletionStatus = null;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/customers";
		try {
			if (customerIds != null) {
				CloseableHttpClient httpClient = HttpClients.createDefault();
				HttpDeleteWithBody httpRequest = new HttpDeleteWithBody(url);
				JSONObject json = new JSONObject();
				json.put("customerIds", customerIds);
				StringEntity params = new StringEntity(json.toString(), "UTF-8");
				logger.info("Http Request Body is :" + params);
				httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
				httpRequest.addHeader("charset", "UTF-8");
				httpRequest.setEntity(params);
				HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
				int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
				logger.info("Http Response is : " + httpResponse);
				logger.info("Http Response status code is : " + httpStatusCode);
				String httpResponseBody = EntityUtils.toString(httpResponse.getEntity());
				if (httpStatusCode == 200 && httpResponseBody.equals(OperationStatus.SUCCESS)) {
					if (this.getCustomers().size() == 0) {
						usersDeletionStatus = OperationStatus.NO_DATA;
					} else {
						usersDeletionStatus = OperationStatus.SUCCESS;
					}
				} else {
					usersDeletionStatus = OperationStatus.FAILURE;
					context.addMessage(null,
							new FacesMessage(i18nResourceBundle.getString("method.deletecustomer.failure")));
				}
			} else {
				throw new NullPointerException("Customer Ids are not passed to delete");
			}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException is raised", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception ex) {
			logger.error("Exception occured in deleteSelected() method", ex);
		}
		return usersDeletionStatus;
	}
}
