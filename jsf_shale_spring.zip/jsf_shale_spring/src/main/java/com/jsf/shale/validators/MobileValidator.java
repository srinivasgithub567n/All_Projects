package com.jsf.shale.validators;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

/**
 * 
 * @author srinivasa.nayana
 *
 */
public class MobileValidator implements Validator {
	/**
	 * this method is used to validate the mobile number.
	 * 
	 * if mobile no entered by user doesn't match the regular expression defined
	 * then validation message is sent back to the user. else user is allowed to
	 * move further in the jsf page.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		String enteredMobile = value.toString();
		Pattern regEx = Pattern.compile("[0-9]{10}");
		Matcher match = regEx.matcher(enteredMobile);
		boolean matchFound = match.matches();
		if (!matchFound) {
			FacesMessage message = new FacesMessage();
			message.setSummary("mobile no should contain only digits");
			throw new ValidatorException(message);
		}
	}
}
