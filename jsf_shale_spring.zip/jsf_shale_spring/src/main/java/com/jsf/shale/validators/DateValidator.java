package com.jsf.shale.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * 
 * @author EI11321
 *
 */
public class DateValidator implements Validator {
	private static final Logger logger = Logger.getLogger(DateValidator.class);

	/**
	 * this method is responsible of validating the Date.
	 * 
	 * it checks the format of the date entered . if it's not matching with the pattern defined , corresponding validation
	 * error is thrown else it proceed with further validations such as invalid date , month and year.
	 * 
	 * if anything is invalid , validation error is thrown back else it allows to move further.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		logger.info("**Entered into Date Validator ******");
		String date = (String) value;
		FacesMessage message = new FacesMessage();
		logger.info("*** Entered date is : " + date);
		Pattern pattern = Pattern.compile("[0-9]{2}-[0-9]{2}-[0-9]{4}");
		Matcher match = pattern.matcher(date);
		boolean matchFound = match.matches();
		if (!matchFound) {
			logger.info("**** date format is not matched ******");
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.date.format"));
			throw new ValidatorException(message);
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String[] dateSplit = date.split("-");
		int day = Integer.parseInt(dateSplit[0]);
		int month = Integer.parseInt(dateSplit[1]);
		int year = Integer.parseInt(dateSplit[2]);
		logger.info("*********day , Month and Year are :" + day + "," + month + "," + year);
		if (day == 0 | day > 31) {
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.date.invaliddate"));
			throw new ValidatorException(message);
		}
		if (month == 0 | month > 12) {
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.date.invalidmonth"));
			throw new ValidatorException(message);
		}
		if (year < 1900 | year > 2019) {
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.date.invalidyear"));
			throw new ValidatorException(message);
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		int currentYear = calendar.get(Calendar.YEAR);
		int currentMonthTemp = calendar.get(Calendar.MONTH);
		int currentMonth = currentMonthTemp + 1;
		int currentDay = calendar.get(Calendar.DAY_OF_MONTH);
		logger.info(
				"*** Current Year , Month and Date are *******" + currentYear + "," + currentMonth + "," + currentDay);
		if (year == currentYear) {
			if (month > currentMonth) {
				message.setSummary(i18nResourceBundle.getString("app.employee.validation.date.futuredate"));
				throw new ValidatorException(message);
			} else if (month == currentMonth) {
				if (day > currentDay) {
					message.setSummary(i18nResourceBundle.getString("app.employee.validation.date.futuredate"));
					throw new ValidatorException(message);
				}
			}
		}
	}
}
