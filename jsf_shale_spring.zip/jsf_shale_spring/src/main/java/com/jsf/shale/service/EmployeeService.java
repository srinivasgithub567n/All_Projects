package com.jsf.shale.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.jsf.shale.model.DropDownList;
import com.jsf.shale.model.Employee;

public interface EmployeeService {
	public String createEmployee(Employee employee)throws ClientProtocolException, IOException,SQLException;

	public List<DropDownList> getDropDownList() throws ParseException, IOException, SQLException;

	public List<Employee> getEmployeeList() throws JsonParseException, JsonMappingException, IOException, SQLException;
}
