package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

/**
 * 
 * @author EI11321
 *
 */
public class ReportingToValidator implements Validator {
	
	/**
	 * this method verifies whether one of reporting persons is selected from the drop down.
	 * if not , validation error occurs.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String reportTo = (String) value;
		if (reportTo.equals("-1")) {
			FacesMessage message = new FacesMessage();
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.reportingto.required"));
			throw new ValidatorException(message);
		}
	}
}
