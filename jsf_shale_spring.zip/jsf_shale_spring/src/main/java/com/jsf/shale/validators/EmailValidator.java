package com.jsf.shale.validators;

import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * 
 * @author srinivasa.nayana
 *
 */
public class EmailValidator implements Validator {
	/**
	 * this method is used to apply the email validation . if email id entered by
	 * user is not matching pattern defined, it sends the validation message back to
	 * the user
	 * 
	 * else it allows the user to move further
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String enteredEmail = (String) value;
		Pattern pattern = Pattern.compile(".+@.+\\.[a-z]+");
		Matcher match = pattern.matcher(enteredEmail);
		boolean matchFound = match.matches();
		if (!matchFound) {
			FacesMessage message = new FacesMessage();
			message.setSummary(i18nResourceBundle.getString("app.custom.validator.email.invalid"));
			throw new ValidatorException(message);
		}
	}
}
