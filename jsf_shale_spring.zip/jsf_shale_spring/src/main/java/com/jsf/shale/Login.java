package com.jsf.shale;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.apache.log4j.Logger;

import com.jsf.shale.model.UserInfo;
import com.jsf.shale.service.RegistrationService;
import com.jsf.shale.util.OperationStatus;
import com.jsf.shale.util.SessionContext;

/**
 * 
 * 
 * @author srinivasa.nayana
 * 
 *         Backing or Managed bean which is bound to JSF Login page.
 *
 */
public class Login {
	private static final Logger logger = Logger.getLogger(Login.class);
	private String emailId;
	private String password;
	private RegistrationService registrationService;
	private String locale;
	private Map<String, Object> countries;
	private String loggedInUser;

	public String getLoggedInUser() {
		String loggedInUserFullName = SessionContext.getInstance().getCurrentSessionn().getAttribute("user").toString();
		logger.info("Logged in user first name :" + loggedInUserFullName);
		return loggedInUserFullName;
	}

	public void setLoggedInUser(String loggedInUser) {
		this.loggedInUser = loggedInUser;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public Map<String, Object> getCountries() {
		countries = new LinkedHashMap<String, Object>();
		countries.put("English", "en");
		countries.put("Swedish", "sv");
		return countries;
	}

	public void setCountries(Map<String, Object> countries) {
		this.countries = countries;
	}

	public RegistrationService getRegistrationService() {
		return registrationService;
	}

	public void setRegistrationService(RegistrationService registrationService) {
		this.registrationService = registrationService;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * 
	 * @return String which represents the status of the login verification
	 * 
	 */
	public String loginVerify() {
		logger.info("Entered into loginVerify() method");
		logger.info("*********current date is ********** :"+new Date());
		String logginStatus = null;
		UserInfo loggedInCustomer = registrationService.loginVerify(this);
		logger.info("Logged in user details: " + loggedInCustomer);
		if (loggedInCustomer != null)
			logginStatus = OperationStatus.SUCCESS;
		else
			logginStatus = OperationStatus.INVALID;
		return logginStatus;
	}

	/**
	 * 
	 * @return String which represents the status of destruction of the session
	 */
	public String destroySession() {
		logger.info("Entered into destroySession() method");
		SessionContext.getInstance().destroySession();
		return OperationStatus.SUCCESS;
	}

	/**
	 * 
	 * @param event
	 *            of type ValueChangeEvent is accepted. this method is called when
	 *            value change event happens in JSF component of home_page.jsp that
	 *            it's bound and used to set the locale with respect to
	 *            internationalization
	 */
	public void localeChanged(ValueChangeEvent event) {
		logger.info("Entered into localeChanged() event listner method ");
		String newLocaleValue = event.getNewValue().toString();
		logger.info("Locale chosen by user : " + newLocaleValue);
		for (Map.Entry<String, Object> entry : countries.entrySet()) {
			if (entry.getValue().toString().equals(newLocaleValue)) {
				FacesContext.getCurrentInstance().getViewRoot().setLocale(new Locale(entry.getValue().toString()));
			}
		}
	}
}
