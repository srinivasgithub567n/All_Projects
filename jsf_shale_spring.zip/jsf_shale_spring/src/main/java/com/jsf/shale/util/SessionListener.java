package com.jsf.shale.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.apache.log4j.Logger;

import com.jsf.shale.ImageServlet;

public class SessionListener implements HttpSessionListener {
	private static final Logger logger = Logger.getLogger(SessionListener.class);

	/**
	 * @param event
	 *            this method is called at the time of session creation
	 */
	public void sessionCreated(HttpSessionEvent httpSessionEvent) {
		logger.info("session is  Created and Id is : " + httpSessionEvent.getSession().getId());
	}

	/**
	 * @param event
	 *            this method is called at the session destruction
	 */
	public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
		String lastAccess = (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"))
				.format(new Date(httpSessionEvent.getSession().getLastAccessedTime()));
		logger.info("****** Setting Image Servlet's  byte array to null *******");
		ImageServlet.sendImageBytes(null);
		logger.info("session is expired  " + httpSessionEvent.getSession().getId() + ". Last access = " + lastAccess);
	}
}
