package com.jsf.shale.util;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 * 
 * @author srinivasa.nayana
 * 
 *         this class is used to instruct the browser not to store the jsf pages
 *         in it's cache.
 *
 */
public class NoCacheFilter implements Filter {
	private static final Logger logger = Logger.getLogger(NoCacheFilter.class);

	/**
	 * this method is called at the time of filter initialization
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		logger.info("No Chache filter is initialized");
	}

	/**
	 * this method contains the logic to instruct the browser not to cache any jsf
	 * pages of application to restrict the user not to see previous pages after log
	 * out
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		String requestURI = httpServletRequest.getRequestURI();
		if (requestURI.contains(".jsp")) {
			httpServletResponse.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			httpServletResponse.setDateHeader("Expires", 0); // Proxies.
		}
		chain.doFilter(request, response);
	}

	/**
	 * this method is called at the time of filter destruction
	 */
	public void destroy() {
		logger.info("No cache filter is destroyed");
	}
}
