package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * 
 * @author EI11321
 *
 */
public class DateOfBirthValidator implements Validator {
	private static final Logger logger = Logger.getLogger(DateOfBirthValidator.class);

	/**
	 * this method is used to apply date of birth validation.
	 * 
	 * date of birth entered is passed to DateOfJoining custom validation to verify with it
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		logger.info("********** Entered into Date of Birth Validator method ********");
		String dateOfBirth = (String) value;
		logger.info("*********Date of Birth received in date of birth validator method is :" + dateOfBirth);
		DateOfJoiningValidator.sendDateOfBirth(dateOfBirth);
	}
}
