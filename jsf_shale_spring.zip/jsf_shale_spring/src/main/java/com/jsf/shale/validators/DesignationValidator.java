package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

/**
 * 
 * @author EI11321
 *
 */
public class DesignationValidator implements Validator {
	
	/**
	 * this method is responsible of checking whether one of the designations from the drop down is selected or not. if not 
	 * 
	 * validation error is thrown back.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String designation = (String) value;
		if (designation.equals("-1")) {
			FacesMessage message = new FacesMessage();
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.designation.required"));
			throw new ValidatorException(message);
		}
	}
}
