package com.jsf.shale.util;

import java.util.ResourceBundle;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * 
 * @author srinivasa.nayana
 *
 */
public class SessionContext {
	private static SessionContext instance;

	/**
	 * 
	 * @return SessionContext singleton object
	 */
	public static SessionContext getInstance() {
		if (instance == null) {
			instance = new SessionContext();
		}
		return instance;
	}

	// default constructor
	private SessionContext() {
	}

	/**
	 * 
	 * @return ExternalContext of Faces context
	 */
	private ExternalContext currentExternalContext() {
		if (FacesContext.getCurrentInstance() == null) {
			throw new RuntimeException("FacesContext can�t be called outside of a HTTP request");
		} else {
			return FacesContext.getCurrentInstance().getExternalContext();
		}
	}

	// this is to invalidate (destroy ) the session.
	public void destroySession() {
		((HttpSession) currentExternalContext().getSession(false)).invalidate();
	}

	/**
	 * 
	 * @return HttpSession of new
	 */
	public HttpSession getNewSession() {
		return ((HttpServletRequest) currentExternalContext().getRequest()).getSession(true);
	}

	/**
	 * 
	 * @return HttpSession of existing
	 */
	public HttpSession getCurrentSessionn() {
		return ((HttpServletRequest) currentExternalContext().getRequest()).getSession(false);
	}

	/**
	 * 
	 * @param bundleVariable
	 *            of type String is accepted .this represents variable of resource
	 *            bundle defined in faces-config.xml file .
	 * @return ResourceBundle which points to object of resource bundle .
	 */
	public static ResourceBundle getResouceBundle(String bundleVariable) {
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle resourceBundleI18n = context.getApplication().getResourceBundle(context, bundleVariable);
		return resourceBundleI18n;
	}
}
