package com.jsf.shale.service;

import java.util.List;
import com.jsf.shale.Login;
import com.jsf.shale.User;
import com.jsf.shale.model.UserInfo;

public interface RegistrationService {
	public String addUser(UserInfo userInfo);

	public UserInfo loginVerify(Login loginCredentials);

	public List<UserInfo> getCustomers();

	public String updateCustomer(UserInfo userInfo);

	public String deleteCustomer(UserInfo userInfo);

	public String deleteSelectedCustomers(int[] customerIds);
}
