package com.jsf.shale;

import java.util.ResourceBundle;
import javax.faces.context.FacesContext;
import org.apache.log4j.Logger;

/**
 * 
 * @author srinivasa.nayana
 *
 */
public class InternationalizationMessages {
	private static final Logger logger = Logger.getLogger(InternationalizationMessages.class);
	private String passwordMisMatchMsg;

	/**
	 * 
	 * @return String which passes the password miss match information to the
	 *         browser
	 */
	public String getPasswordMisMatchMsg() {
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		logger.info("Password miss match message" + i18nResourceBundle.getString("app.alert.passwordmismtach"));
		return i18nResourceBundle.getString("app.alert.passwordmismtach");
	}

	/**
	 * 
	 * @param accepts
	 *            passwordMisMatchMsg of type String to set the property value.
	 */
	public void setPasswordMisMatchMsg(String passwordMisMatchMsg) {
		this.passwordMisMatchMsg = passwordMisMatchMsg;
	}
}
