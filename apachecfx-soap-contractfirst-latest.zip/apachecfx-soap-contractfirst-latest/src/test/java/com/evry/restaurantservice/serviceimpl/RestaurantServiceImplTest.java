package com.evry.restaurantservice.serviceimpl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RestaurantServiceImplTest {

	@Test
	void testAddRestaurant() {
		fail("Not yet implemented");
	}

	@Test
	void testGetRestaurantList() {
		fail("Not yet implemented");
	}

	@Test
	void testAddMenu() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteMenu() {
		fail("Not yet implemented");
	}

	@Test
	void testGetMenuList() {
		fail("Not yet implemented");
	}

}
