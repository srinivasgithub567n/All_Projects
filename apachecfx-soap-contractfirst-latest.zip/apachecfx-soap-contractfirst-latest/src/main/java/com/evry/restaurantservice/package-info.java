@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.evry.com/RestaurantService/")
package com.evry.restaurantservice;
