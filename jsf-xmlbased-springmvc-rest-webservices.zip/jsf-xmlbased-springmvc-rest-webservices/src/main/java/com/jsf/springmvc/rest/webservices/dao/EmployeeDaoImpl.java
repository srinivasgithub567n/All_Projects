package com.jsf.springmvc.rest.webservices.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.jsf.springmvc.rest.webservices.customexceptions.UpdateToInactiveEmployee;
import com.jsf.springmvc.rest.webservices.customexceptions.UserNotExist;
import com.jsf.springmvc.rest.webservices.model.DropDownList;
import com.jsf.springmvc.rest.webservices.model.Employee;
import com.jsf.springmvc.rest.webservices.model.PromotionHistory;
import com.jsf.springmvc.rest.webservices.util.HibernateUtil;
import com.jsf.springmvc.rest.webservices.util.OperationStatus;

/**
 * 
 * @author EI11321
 * 
 *  this class acts as DAO layer to interact with Data base.
 *
 */
@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	private static final Logger logger = Logger.getLogger(EmployeeDaoImpl.class);
	// autowired annotation is used to implicitly identify the bean class and inject it's bean.
	@Autowired
	private HibernateUtil hibernateUtil;

	/**
	 * @param employee
	 * @param operation
	 * @return String
	 * 
	 * this method is used to create new employee or update the existing employee in the table 'employee_details' by interacting 
	 * with Data base based on the operation passed to it.
	 * 
	 * if it's create , then new employee record is inserted into the table else existing employee gets updated.
	 * 
	 * employee status is set(active or inactive ) based on the end date before inserting the record.
	 * current designation is added to the table 'promotion_history' which is child table to 'employee_details' with
	 * 'OneToMany' relation if it's new employee.
	 * 
	 * in case of update to the employee , existing designation and designation of updated record are verified and added accordingly.
	 * 
	 * 
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public String createOrUpdateEmployee(Employee employee, String operation) throws IOException, SQLException {
		Session session = null;
		String status = OperationStatus.SUCCESS;
		session = hibernateUtil.getSession();
		if (employee != null) {
			if (operation == "create") {
				PromotionHistory promotion = null;
				logger.info("Details received at Dao layer :" + employee.getName() + "," + employee.getDesignation()
						+ "," + employee.getDateOfBirth() + "," + employee.getDepartment() + ","
						+ employee.getReportTo() + "," + employee.getGender() + "," + employee.getDateOfJoining() + ","
						+ employee.getPrimarySkill() + "," + employee.getStartDate() + "," + employee.getEndDate() + ","
						+ employee.getLocation());
				if (employee.getEndDate() != null) {
					employee.setStatus("inactive");
				} else {
					employee.setStatus("active");
				}
				if (employee.getPromotionList().size() == 0) {
					logger.info(
							"*** Entered into If block where size of the promotion list of employee is zero *********");
					promotion = new PromotionHistory();
					promotion.setDesignation(employee.getDesignation());
					promotion.setStartDate(employee.getStartDate());
					promotion.setEndDate(null);
					employee.getPromotionList().add(promotion);
				}
				logger.info("****** Before employe create query **********");
				session.save(employee);
				logger.info("******* After employee create query *********");
			} else {
				Employee employeeRecord = (Employee) session.get(Employee.class, employee.getId());
				if (employeeRecord != null) {
					if (employeeRecord.getEndDate() != null) {
						throw new UpdateToInactiveEmployee("Inactive Employee cannot be updated");
					}
					if (employee.getEndDate() != null) {
						logger.info("********** End date is not null and changing the status to 'inactive' ******* :"
								+ employee.getEndDate());
						employee.setStatus("inactive");
					} else {
						logger.info("******** End date is null and changing the status to 'active ' ******* :"
								+ employee.getEndDate());
						employee.setStatus("active");
					}
					if (!(employee.getDesignation().equals(employeeRecord.getDesignation()))) {
						logger.info("********* Existing and Lastest designation are :" + employeeRecord.getDesignation()
								+ "," + employee.getDesignation());
						PromotionHistory promotion = null;
						int count = 0;
						for (PromotionHistory promotionFromList : employeeRecord.getPromotionList()) {
							if (employee.getDesignation().equals(promotionFromList.getDesignation())) {
								count++;
								break;
							} else {
								continue;
							}
						}
						if (count == 0) {
							PromotionHistory lastRecordOfPromotionList = employeeRecord.getPromotionList()
									.get(employeeRecord.getPromotionList().size() - 1);
							logger.info("******** Latest record of promotion list is retrieved *************");
							Date currentDate = new Date();
							Date previousDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
							lastRecordOfPromotionList.setEndDate(previousDate);
							promotion = new PromotionHistory();
							promotion.setDesignation(employee.getDesignation());
							promotion.setStartDate(currentDate);
							promotion.setEndDate(null);
							employeeRecord.getPromotionList().add(promotion);
							logger.info("***** Promotion is sucessfully added to the list **********");
						} else {
							logger.info(
									"****** promotion alread existed in the promotion history error needs to be thrown explicitly ********");
						}
					}
					employeeRecord.setId(employee.getId());
					employeeRecord.setName(employee.getName());
					employeeRecord.setDesignation(employee.getDesignation());
					employeeRecord.setDateOfBirth(employee.getDateOfBirth());
					employeeRecord.setDepartment(employee.getDepartment());
					employeeRecord.setReportTo(employee.getReportTo());
					employeeRecord.setGender(employee.getGender());
					employeeRecord.setDateOfJoining(employee.getDateOfJoining());
					employeeRecord.setPrimarySkill(employee.getPrimarySkill());
					employeeRecord.setStartDate(employee.getStartDate());
					employeeRecord.setEndDate(employee.getEndDate());
					employeeRecord.setLocation(employee.getLocation());
					employeeRecord.setManagerStatus(employee.getManagerStatus());
					employeeRecord.setUploadedImage(employee.getUploadedImage());
					employeeRecord.setStatus(employee.getStatus());
					logger.info("********  Before employee update query ******");
					session.update(employeeRecord);
					logger.info("******** After emplooyee update query******");
				} else {
					throw new UserNotExist("user not exist to update the details");
				}
			}
		}
		return status;
	}

	/**
	 * @param dropDownItem
	 * @return String
	 * 
	 * this method interacts with DB and create new drop down item in the table 'dropdown_list'
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public String addDropDownItem(DropDownList dropDownItem) throws IOException, SQLException {
		Session session = null;
		String status = OperationStatus.SUCCESS;
		session = hibernateUtil.getSession();
		if (dropDownItem != null) {
			logger.info("Drop down item  received at Dao layer :" + dropDownItem.getItemLabel() + ","
					+ dropDownItem.getItemCategory());
			session.save(dropDownItem);
		}
		return status;
	}

	/**
	 * @return List<DropDownList>
	 * this method interacts with DB to retrieve the list of drop down items from the table 'dropdown_list'
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public List<DropDownList> getDropDownList() throws IOException, SQLException {
		Session session = null;
		List<DropDownList> dropDownList = null;
		String sql = "from DropDownList";
		session = hibernateUtil.getSession();
		dropDownList = session.createQuery(sql).list();
		return dropDownList;
	}

	/**
	 * @return List<Employee>
	 * 
	 * this method interacts with DB to retrieve the list of employees from the table 'employee_details'
	 */
	@Override
	public List<Employee> getEmployeeList() throws IOException, SQLException {
		Session session = null;
		List<Employee> employeeList = null;
		String sql = "from Employee";
		session = hibernateUtil.getSession();
		employeeList = session.createQuery(sql).list();
		return employeeList;
	}
}
