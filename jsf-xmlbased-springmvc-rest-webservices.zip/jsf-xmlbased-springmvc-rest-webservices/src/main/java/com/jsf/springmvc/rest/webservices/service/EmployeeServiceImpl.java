package com.jsf.springmvc.rest.webservices.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.jsf.springmvc.rest.webservices.dao.EmployeeDao;
import com.jsf.springmvc.rest.webservices.model.DropDownList;
import com.jsf.springmvc.rest.webservices.model.Employee;

/**
 * 
 * @author EI11321
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
	//autowired annotation instructs the spring frame work to identify the bean class from the application context and inject it's bean impicitly
	@Autowired
	private EmployeeDao employeeDao;

	/**
	 * @param employee
	 * @param operation
	 * @return String
	 * 
	 * this method passes the employee object and name of the operation to the method of employee DAO layer
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public String createOrUpdateEmployee(Employee employee, String operation) throws IOException, SQLException {
		return employeeDao.createOrUpdateEmployee(employee, operation);
	}

	/**
	 * @param dropDownItem
	 * @return String
	 * 
	 * this method passes the drop down item details to the method of employee DAO layer
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public String addDropDownItem(DropDownList dropDownItem) throws IOException, SQLException {
		return employeeDao.addDropDownItem(dropDownItem);
	}

	/**
	 * @return List<DropDownList>
	 * this method retrieves the list of drop down items by invoking the method of employee DAO layer.
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public List<DropDownList> getDropDownList() throws IOException, SQLException {
		return employeeDao.getDropDownList();
	}

	/**
	 * @return List<Employee>
	 * this method retrieves list of employees by invoking the method of employee DAO layer.
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public List<Employee> getEmployeeList() throws IOException, SQLException {
		return employeeDao.getEmployeeList();
	}
}
