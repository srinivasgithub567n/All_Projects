package com.jsf.springmvc.rest.webservices.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "EMPLOYEE_DETAILS")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id",length=10)
	private int id;
	@Column(name = "NAME",nullable=false,length=50)
	private String name;
	@Column(name = "Designation",nullable=false,length=5)
	private String designation;
	@Column(name = "Date_Of_Birth",nullable=false)
	private Date dateOfBirth;
	@Column(name = "Department",nullable=false,length=5)
	private String department;
	@Column(name = "Reporting_To",nullable=false,length=5)
	private String reportTo;
	@Column(name = "Gender",nullable=false,length=5)
	private String gender;
	@Column(name = "Date_Of_Joining",nullable=false)
	private Date dateOfJoining;
	@Column(name = "Pramary_Skill",nullable=false,length=5)
	private String primarySkill;
	@Column(name = "Strat_Date",nullable=false)
	private Date startDate;
	@Column(name = "End_Date")
	private Date endDate;
	@Column(name = "Status",nullable=false,length=5)
	private String status;
	@Column(name = "Location",nullable=false,length=5)
	private String location;
	@Column(name = "Manager_Status",length=3)
	private String managerStatus;
	@Lob
	@Column(name = "Employee_Photo")
	private byte[] uploadedImage;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the uploadedImage
	 */
	public byte[] getUploadedImage() {
		return uploadedImage;
	}

	/**
	 * @param uploadedImage
	 *            the uploadedImage to set
	 */
	public void setUploadedImage(byte[] uploadedImage) {
		this.uploadedImage = uploadedImage;
	}

	/**
	 * @return the managerStatus
	 */
	public String getManagerStatus() {
		return managerStatus;
	}

	/**
	 * @param managerStatus
	 *            the managerStatus to set
	 */
	public void setManagerStatus(String managerStatus) {
		this.managerStatus = managerStatus;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * @param designation
	 *            the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth
	 *            the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the reportTo
	 */
	public String getReportTo() {
		return reportTo;
	}

	/**
	 * @param reportTo
	 *            the reportTo to set
	 */
	public void setReportTo(String reportTo) {
		this.reportTo = reportTo;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the dateOfJoining
	 */
	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	/**
	 * @param dateOfJoining
	 *            the dateOfJoining to set
	 */
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	/**
	 * @return the primarySkill
	 */
	public String getPrimarySkill() {
		return primarySkill;
	}

	/**
	 * @param primarySkill
	 *            the primarySkill to set
	 */
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "employee_id")
	List<PromotionHistory> promotionList = new ArrayList<PromotionHistory>();

	/**
	 * @return the promotionList
	 */
	public List<PromotionHistory> getPromotionList() {
		return promotionList;
	}

	/**
	 * @param promotionList
	 *            the promotionList to set
	 */
	public void setPromotionList(List<PromotionHistory> promotionList) {
		this.promotionList = promotionList;
	}
}
