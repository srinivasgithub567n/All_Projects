package com.jsf.springmvc.rest.webservices.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.jsf.springmvc.rest.webservices.customexceptions.EmailAlreadyExists;
import com.jsf.springmvc.rest.webservices.customexceptions.InvalidUser;
import com.jsf.springmvc.rest.webservices.customexceptions.UserNotExist;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.CustomerIds;
import com.jsf.springmvc.rest.webservices.model.Login;
import com.jsf.springmvc.rest.webservices.util.HibernateUtil;
import com.jsf.springmvc.rest.webservices.util.OperationStatus;

/**
 * 
 * @author srinivasa.nayana this class acts as DAO layer to interact with Data
 *         base
 */
@Repository
public class RegistrationDaoImpl implements RegistrationDao {
	private static final Logger logger = Logger.getLogger(RegistrationDaoImpl.class);
	// autowired annotation is used to implicitly identify the bean class and inject it's bean.
	@Autowired
	private HibernateUtil hibernateUtil;

	/**
	 * @param customerDetails
	 * @return String
	 * 
	 *         this method interacts with data base and creates the recored of new
	 *         user into the table 'Customer_Details' before creating the record ,
	 *         it verifies if any user existed in the table with same email id. if
	 *         yes, it would not allow to create user record with the existing email
	 *         id if not , it allows to register successfully.
	 */
	
	
	
    @Transactional(propagation=Propagation.REQUIRED,rollbackFor = Exception.class)
	@Override
	public String createOrUpdateUser(Customer customerDetails, String operation) throws IOException, SQLException {
		Session session = null;
	
		String status = OperationStatus.SUCCESS;
	
			session = hibernateUtil.getSession();
	
			if (operation == "create") {
				if (customerDetails != null) {
					logger.info("user details received by CreateUser() are : " + customerDetails.getFirstName() + ","
							+ customerDetails.getLastName() + "," + customerDetails.getEmailId() + ","
							+ customerDetails.getMobileNo());
					String sql = "from Customer where emailId='" + customerDetails.getEmailId() + "'";
					List<Customer> user = session.createQuery(sql).list();
					if (user.size() >= 1) {
						throw new EmailAlreadyExists("Already email existed. please try some other one");
					} else {
						session.save(customerDetails);

					}
				}
				
			
			} else {
				Customer customer = (Customer)session.get(Customer.class, customerDetails.getId());
				if (customer != null) {
					customer.setFirstName(customerDetails.getFirstName());
					customer.setLastName(customerDetails.getLastName());
					customer.setEmailId(customerDetails.getEmailId());
					customer.setMobileNo(customerDetails.getMobileNo());
					session.update(customer);
				} else {
					throw new UserNotExist("user not exist to update the details");
				}
	
			}

		return status;
	}

	/**
	 * 
	 * @param loginCredentials
	 * @return Customer
	 * 
	 *         this method interacts with data base and retrieves the user record
	 *         based on the email id and password . if record exists , then it's
	 *         returned
	 * 
	 */
	
    @Transactional(propagation=Propagation.REQUIRED,rollbackFor = Exception.class)
	@Override
	public Customer loginVerify(Login loginCredentials) throws IOException, SQLException {
		Session session = null;
	//Transaction transaction = null;
		Customer loggedInCustomer = null;
		String sql = "from Customer where emailId='" + loginCredentials.getEmailId() + "' and password='"
				+ loginCredentials.getPassword() + "'";
	//try {
			session = hibernateUtil.getSession();
		//transaction = session.beginTransaction();
			if (loginCredentials != null) {
				List<Customer> user = session.createQuery(sql).list();
				if (user.size() == 1) {
					loggedInCustomer = user.get(0);
				} else {
					throw new InvalidUser("Not an authenticated user");
				}
	}
		//	transaction.commit();
	/*} catch (Exception exception) {
			transaction.rollback();
			throw exception;
		}*/
		return loggedInCustomer;
	}

	/**
	 * @return List<Customer>
	 * 
	 *         this method interacts with data base and retrieves all the user
	 *         records from the table 'Customer_Details'
	 */
    
    @Transactional(propagation=Propagation.REQUIRED,rollbackFor = Exception.class)
	@Override
	public List<Customer> getCustomers() throws IOException, SQLException {
		Session session = null;
		//Transaction transaction = null;
		List<Customer> customersList = null;
		String sql = "from Customer";
	//	try {
			session = hibernateUtil.getSession();
		//	transaction = session.beginTransaction();
			customersList = session.createQuery(sql).list();
		//	transaction.commit();
		/*} catch (Exception exception) {
			transaction.rollback();
			throw exception;
		}*/
		return customersList;
	}

	/**
	 * @param id
	 * @return String
	 * 
	 *         this method interacts with data base and deletes the user record
	 *         based on the id received from the table 'Customer_Details' and
	 *         returns the status accordingly .
	 * 
	 */
    
    @Transactional(propagation=Propagation.REQUIRED,rollbackFor = Exception.class)
	@Override
	public String deleteOneOrMutipleCustomers(CustomerIds customerIds) throws IOException, SQLException {
		Session session = null;
	//	Transaction transaction = null;
		List<Customer> customersList = null;
		String status = OperationStatus.SUCCESS;
		String sql = "from Customer";
	//	try {
			int[] ids = customerIds.getCustomerIds();
			session = hibernateUtil.getSession();
		//	transaction = session.beginTransaction();
			if (ids.length != 0) {
				for (int customerId : ids) {
					Customer customer = (Customer)session.get(Customer.class, customerId);
					if (customer != null) {
						session.delete(customer);
						customersList = session.createQuery(sql).list();// need to delete this by verifying whether it's required or not
					} else {
						throw new UserNotExist("User with Id: " + customerId + " doesnt' exist to delete");
					}
				}
			}
			//transaction.commit();
		/*} catch (Exception exception) {
			transaction.rollback();
			throw exception;
		}*/
		return status;
	}
}
