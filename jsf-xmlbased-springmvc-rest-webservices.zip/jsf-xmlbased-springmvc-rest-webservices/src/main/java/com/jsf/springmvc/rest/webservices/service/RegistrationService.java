package com.jsf.springmvc.rest.webservices.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.CustomerIds;
import com.jsf.springmvc.rest.webservices.model.Login;



public interface RegistrationService {
	public String createOrUpdateUser(Customer customerDetails, String operation) throws IOException, SQLException;

	public Customer loginVerify(Login loginCredentials) throws IOException, SQLException;

	public List<Customer> getCustomers() throws IOException, SQLException;

	public String deleteOneOrMutipleCustomers(CustomerIds customerIds) throws IOException, SQLException;
}
