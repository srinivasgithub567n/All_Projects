package com.jsf.springmvc.rest.webservices.model;

import java.util.Arrays;

public class CustomerIds {
	int[] customerIds;

	public int[] getCustomerIds() {
		return customerIds;
	}

	public void setCustomerIds(int[] customerIds) {
		this.customerIds = customerIds;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(customerIds);
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerIds other = (CustomerIds) obj;
		if (!Arrays.equals(customerIds, other.customerIds))
			return false;
		return true;
	}
	
	
}
