package com.jsf.springmvc.rest.webservices.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.jsf.springmvc.rest.webservices.dao.RegistrationDao;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.CustomerIds;
import com.jsf.springmvc.rest.webservices.model.Login;

/**
 * 
 * @author srinivasa.nayana
 * 
 *
 */
@Service
public class RegistrationServiceImpl implements RegistrationService {
	// autowired annotation instructs the spring frame work to identify the bean
	// class from the application context and inject it's bean impicitly
	@Autowired
	private RegistrationDao registrationDao;
	
	
	public RegistrationServiceImpl(RegistrationDao registrationDao)
	{
		this.registrationDao=registrationDao;
	}

	/**
	 * @param customerDetails
	 * @return String
	 * 
	 *         this method is used to create the new user by passing the user
	 *         details to method of Dao laye's class
	 */
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor = Exception.class)
	@Override
	public String createOrUpdateUser(Customer customerDetails, String operation) throws IOException, SQLException {
		return registrationDao.createOrUpdateUser(customerDetails, operation);
	}

	/**
	 * @param loginCredentials
	 * @return Customer
	 * 
	 *         this method is used to verify user credentials by passing the details
	 *         to the method of dao layer's class.
	 */
	@Override
	public Customer loginVerify(Login loginCredentials) throws IOException, SQLException {
		return registrationDao.loginVerify(loginCredentials);
	}

	/**
	 * @return List<Customer>
	 * 
	 *         this method is used to retrieve the list of users existed by callign
	 *         the method of Dao layer's class.
	 */
	@Override
	public List<Customer> getCustomers() throws IOException, SQLException {
		return registrationDao.getCustomers();
	}

	/**
	 * @param id
	 * @return String
	 * 
	 *         this method is used to delete the user based on the user id received
	 *         by calling the method of dao layer's class
	 */
	@Override
	public String deleteOneOrMutipleCustomers(CustomerIds customerIds) throws IOException, SQLException {
		return registrationDao.deleteOneOrMutipleCustomers(customerIds);
	}
}
