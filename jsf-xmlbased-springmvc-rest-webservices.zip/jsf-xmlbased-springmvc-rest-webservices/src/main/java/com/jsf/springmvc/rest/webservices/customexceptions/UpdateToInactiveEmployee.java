package com.jsf.springmvc.rest.webservices.customexceptions;

/**
 * 
 * @author EI11321
 *   UpdateToInactiveEmployee -- custom runtime exception class
 */
public class UpdateToInactiveEmployee extends RuntimeException {
	private static final long serialVersionUID = -4063949149815809819L;

	public UpdateToInactiveEmployee(String message) {
		super(message);
	}
}
