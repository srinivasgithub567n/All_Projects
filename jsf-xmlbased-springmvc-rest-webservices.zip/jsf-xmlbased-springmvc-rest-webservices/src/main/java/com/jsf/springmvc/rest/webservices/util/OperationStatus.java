package com.jsf.springmvc.rest.webservices.util;

public class OperationStatus {
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String INVALID = "invalid";
	public static final String NO_DATA = "no_data";
}
