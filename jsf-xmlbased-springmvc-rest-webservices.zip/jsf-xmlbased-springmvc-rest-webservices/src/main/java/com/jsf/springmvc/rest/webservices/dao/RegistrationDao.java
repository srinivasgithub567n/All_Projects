package com.jsf.springmvc.rest.webservices.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.CustomerIds;
import com.jsf.springmvc.rest.webservices.model.Login;

public interface RegistrationDao {
	public String createOrUpdateUser(Customer customerDetails, String operation) throws IOException, SQLException;

	public Customer loginVerify(Login loginCredentials) throws IOException, SQLException;

	public List<Customer> getCustomers() throws IOException, SQLException;

	public String deleteOneOrMutipleCustomers(CustomerIds customerIds) throws IOException, SQLException;
}
