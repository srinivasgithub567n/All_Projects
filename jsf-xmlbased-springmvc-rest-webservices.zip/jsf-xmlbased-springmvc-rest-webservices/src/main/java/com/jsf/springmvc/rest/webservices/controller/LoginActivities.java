package com.jsf.springmvc.rest.webservices.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.jsf.springmvc.rest.webservices.customexceptions.NoRecordsFound;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.CustomerIds;
import com.jsf.springmvc.rest.webservices.model.Login;
import com.jsf.springmvc.rest.webservices.service.RegistrationService;
import com.jsf.springmvc.rest.webservices.util.OperationStatus;

/**
 * 
 * @author srinivasa.nayana
 * 
 *         LoginActivites is a controller used to map to the corresponding
 *         request handler method based on the url pattern passed in the URL
 *
 */
@RestController
public class LoginActivities {
	private static final Logger logger = Logger.getLogger(LoginActivities.class);
	// @Autowired is used to identify the respective bean class in spring
	// application context and inject it's object.
	@Autowired
	private RegistrationService registrationService;

	/**
	 * 
	 * @param customerDetails
	 * @return String
	 * 
	 *         this method accepts customer details that needs to be created newly
	 *         and returns the string which represents the status of the creation of
	 *         user.
	 * 
	 * @PostMapping annotation is the combination of @RequestMapping and requested
	 *              method such as POST .
	 */
	
	
	
	@PostMapping("/addUser")
	public ResponseEntity<String> createUser(@RequestBody Customer customerDetails) throws IOException, SQLException {
		ResponseEntity<String> responseEntity = null;
		
		 logger.info("User details from controller method :"+customerDetails.getFirstName()+","+customerDetails.getLastName()+","+customerDetails.getEmailId()+","+customerDetails.getMobileNo()+","+customerDetails.getPassword()+","+customerDetails.getId());
		logger.info("User Details received by creatUser() web service :" + customerDetails.getFirstName() + ","
				+ customerDetails.getLastName() + "," + customerDetails.getEmailId() + ","
				+ customerDetails.getMobileNo());
		String operation = "create";
		
		
		String status = registrationService.createOrUpdateUser(customerDetails, operation);
		System.out.println(status);
		if (status.equals(OperationStatus.SUCCESS)) {
			responseEntity = new ResponseEntity<>(status, HttpStatus.OK);
		}
		return responseEntity;
	}

	/**
	 * 
	 * @param customer
	 * @return String
	 * 
	 *         this method is to update the user details.
	 * 
	 * @PutMapping acts as both request mapping and as well as request method such
	 *             as PUT.
	 */
	@PutMapping("/customers/{id}")
	public ResponseEntity<String> updateCustomer(@RequestBody Customer customerDetails)
			throws IOException, SQLException {
		ResponseEntity<String> responseEntity = null;
		logger.info("User details received by updateCustomer() web service  :" + customerDetails.getFirstName() + ","
				+ customerDetails.getLastName() + "," + customerDetails.getEmailId() + ","
				+ customerDetails.getMobileNo());
		String operation = "update";
		String status = registrationService.createOrUpdateUser(customerDetails, operation);
		
		if (status.equals(OperationStatus.SUCCESS)) {
			responseEntity = new ResponseEntity<>(status, HttpStatus.OK);
		}
		return responseEntity;
	}

	/**
	 * 
	 * @param loginCredentials
	 * @return ResponseEntity<Customer>
	 * 
	 *         this method accepts the logincCredentials of user to verify whether
	 *         authenticated or not and returns object of ResponseEntity
	 * 
	 *         if verification is success, ResponseEntity object is filled with http
	 *         response body , http headers (optional) and HtpStatus.OK.
	 * 
	 *         if not , filled with only HttpStatus.NOT_FOUND
	 * 
	 * @PostMapping annotation acts both request mapping as well as request method
	 *              such as POST.
	 * 
	 */
	@SuppressWarnings("unused")
	@PostMapping("/loginVerify")
	public ResponseEntity<Customer> loginVerify(@RequestBody Login loginCredentials) throws IOException, SQLException {
		ResponseEntity<Customer> responseEntity = null;
		logger.info("User credentials received by loginVerify() web service :" + loginCredentials.getEmailId()
				+ ", *********");
		Customer loggedInCustomer = registrationService.loginVerify(loginCredentials);
		if (loggedInCustomer != null) {
			logger.info(
					"Logged In user details : " + loggedInCustomer.getFirstName() + "," + loggedInCustomer.getLastName()
							+ "," + loggedInCustomer.getEmailId() + "," + loggedInCustomer.getMobileNo());
			responseEntity = new ResponseEntity<>(loggedInCustomer, HttpStatus.OK);
		}
		return responseEntity;
	}

	/**
	 * 
	 * 
	 * @return ResponseEntity<List<Customer>> this method is used to retrieve the
	 *         list of users and sent it back as service response if list exists if
	 *         not , it sends only corresponding http reponse status code.
	 * 
	 * @GetMapping annotation acts as both request mapping and request method such
	 *             as GET.
	 */
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getCustomers() throws IOException, SQLException {
		
		List<Customer> customerList = null;
		ResponseEntity<List<Customer>> responseEntity = null;
		if (registrationService != null) {
//			logger.info("size :"+registrationService.getCustomers().size());
			customerList = registrationService.getCustomers();
		} else {
			throw new NullPointerException("registrationService bean is not initialized");
		}
		if (customerList != null) {
			logger.info("Size of the List retrieved  : " + customerList.size());
			if (customerList.size() > 0) {
				responseEntity = new ResponseEntity<>(customerList, HttpStatus.OK);
			} else {
				
				logger.info("no records found exception is thrown from controller");
				throw new NoRecordsFound("No records existed");
			}
		}
		return responseEntity;
	}

	/**
	 * 
	 * @param id
	 * @return String
	 * 
	 *         this method is used to delete the customer based on the id received .
	 * 
	 * @DeleteMapping annotation acts as both request mapping as well as request
	 *                method such as DELETE.
	 */
	@DeleteMapping("/customers/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable int id) throws IOException, SQLException {
		ResponseEntity<String> responseEntity = null;
		CustomerIds customerIds = new CustomerIds();
		customerIds.setCustomerIds(new int[1]);
		customerIds.getCustomerIds()[0] = id;
		logger.info("User id received by deleteCustomer() web service is : " + id);
		String status = registrationService.deleteOneOrMutipleCustomers(customerIds);
		if (status.equals(OperationStatus.SUCCESS)) {
			responseEntity = new ResponseEntity<>(status, HttpStatus.OK);
		}
		return responseEntity;
	}

	/**
	 * 
	 * @param custIds
	 * @return String
	 * 
	 *         this method is used to delete the multiple users at time based on the
	 *         set of Ids received.
	 * 
	 * @DeleteMapping annotation acts as both request mapping as well as request
	 *                method such as DELETE.
	 */
	@DeleteMapping("/customers")
	public ResponseEntity<String> deleteCustomers(@RequestBody CustomerIds customerIds)
			throws IOException, SQLException {
		ResponseEntity<String> responseEntity = null;
		logger.info("User ids received by deleteCustomers() are :");
		for (int userId : customerIds.getCustomerIds()) {
			logger.info(userId);
		}
		String status = registrationService.deleteOneOrMutipleCustomers(customerIds);
		if (status.equals(OperationStatus.SUCCESS)) {
			responseEntity = new ResponseEntity<>(status, HttpStatus.OK);
		}
		return responseEntity;
	}
}
