package com.jsf.springmvc.rest.webservices.customexceptions;

/**
 * 
 * @author EI11321
 *   NoRecordsFound -- custom runtime exception class
 */
public class NoRecordsFound extends RuntimeException {
	private static final long serialVersionUID = -8049412259269264778L;

	public NoRecordsFound(String message) {
		super(message);
	}
}
